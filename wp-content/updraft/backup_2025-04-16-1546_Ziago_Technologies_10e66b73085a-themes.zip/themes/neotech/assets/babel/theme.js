class NeotechTheme {

}

$(document).ready(function () {
    new NeotechTheme();
})
