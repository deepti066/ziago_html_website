<?php
/**
 * Team Loop End
 *
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
    </ul>
</div>